import exp from "express";
import { verifyToken } from "../middlewares/verifyToken.js";
import { authorizeRoles } from "../middlewares/authorizeRoles.js";
import { CourseModel } from "../models/CourseModel.js";
import { EnrollmentModel } from "../models/EnrollmentModel.js";
import { UserTypeModel } from "../models/UserModel.js";
import { buildCourseFilters } from "../services/courseService.js";

export const instructorRoute = exp.Router();

instructorRoute.use(verifyToken, authorizeRoles("INSTRUCTOR"));

instructorRoute.get("/profile", async (req, res, next) => {
  try {
    const instructor = await UserTypeModel.findById(req.user.userId).select("-password");
    res.status(200).json({ message: "Instructor profile fetched", payload: instructor });
  } catch (err) {
    next(err);
  }
});

instructorRoute.post("/courses", async (req, res, next) => {
  try {
    const courseDoc = new CourseModel({
      ...req.body,
      instructorId: req.user.userId,
      lectures: req.body.lectures || [],
    });

    const newCourse = await courseDoc.save();
    res.status(201).json({ message: "Course created", payload: newCourse });
  } catch (err) {
    next(err);
  }
});

instructorRoute.get("/courses", async (req, res, next) => {
  try {
    const filters = buildCourseFilters({ ...req.query, instructorId: req.user.userId });
    const courses = await CourseModel.find(filters).sort({ updatedAt: -1 });
    res.status(200).json({ message: "Instructor courses fetched", payload: courses });
  } catch (err) {
    next(err);
  }
});

instructorRoute.get("/dashboard", async (req, res, next) => {
  try {
    const [instructor, courses] = await Promise.all([
      UserTypeModel.findById(req.user.userId).select("-password"),
      CourseModel.find({ instructorId: req.user.userId }),
    ]);

    const courseIds = courses.map((course) => course._id);
    const enrollments = await EnrollmentModel.find({ courseId: { $in: courseIds } });

    res.status(200).json({
      message: "Instructor dashboard fetched",
      payload: {
        instructor,
        totalCourses: courses.length,
        publishedCourses: courses.filter((course) => course.isPublished).length,
        totalStudents: new Set(enrollments.map((enrollment) => String(enrollment.studentId))).size,
        totalEnrollments: enrollments.length,
        courses,
      },
    });
  } catch (err) {
    next(err);
  }
});

instructorRoute.patch("/courses/:courseId", async (req, res, next) => {
  try {
    const updatedCourse = await CourseModel.findOneAndUpdate(
      { _id: req.params.courseId, instructorId: req.user.userId },
      req.body,
      { new: true, runValidators: true },
    );

    if (!updatedCourse) {
      return res.status(404).json({ message: "Course not found" });
    }

    res.status(200).json({ message: "Course updated", payload: updatedCourse });
  } catch (err) {
    next(err);
  }
});

instructorRoute.post("/courses/:courseId/lectures", async (req, res, next) => {
  try {
    const course = await CourseModel.findOne({
      _id: req.params.courseId,
      instructorId: req.user.userId,
    });

    if (!course) {
      return res.status(404).json({ message: "Course not found" });
    }

    course.lectures.push(req.body);
    await course.save();

    res.status(201).json({ message: "Lecture added", payload: course });
  } catch (err) {
    next(err);
  }
});

instructorRoute.patch("/courses/:courseId/lectures/:lectureId", async (req, res, next) => {
  try {
    const course = await CourseModel.findOne({
      _id: req.params.courseId,
      instructorId: req.user.userId,
    });

    if (!course) {
      return res.status(404).json({ message: "Course not found" });
    }

    const lecture = course.lectures.id(req.params.lectureId);
    if (!lecture) {
      return res.status(404).json({ message: "Lecture not found" });
    }

    Object.assign(lecture, req.body);
    await course.save();

    res.status(200).json({ message: "Lecture updated", payload: course });
  } catch (err) {
    next(err);
  }
});